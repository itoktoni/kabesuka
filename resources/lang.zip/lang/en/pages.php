<?php

return [

    'create' => 'Create',
    'update' => 'Edit',
    'delete' => 'Delete',
    'show' => 'Show',
    'data' => 'Data',
    'back' => 'Back',
    'reset' => 'Reset',
    'save' => 'Save',
    'search' => 'Advance Search',
    'search_button' => 'Search',
    'search_name' => 'Search With',
    'equal' => 'Equals',
    'notequal' => 'Not Equals',
    'contains' => 'Contains',
    'notcontains' => 'Not Contains',
    'more' => 'Greater Than',
    'less' => 'Less Than',

];
