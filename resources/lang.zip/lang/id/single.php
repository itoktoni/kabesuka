<?php

return array (
  'Location' => 'Ruangan',
  'Product' => 'Detail Linen',
  'location' => 'Ruangan',
);
